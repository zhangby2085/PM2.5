2018 Introduction to Machine learning Coursework

Predict next day's PM2.5 pollution based on today's meteorology data.

Several classic statistic and machine learning methods(Ridge/Lasso Regression, Gaussian Kernels) has been applied.

Dataset used:

[UCI ML Dataset]]( https://archive.ics.uci.edu/ml/datasets/Beijing+PM2.5+Data)
